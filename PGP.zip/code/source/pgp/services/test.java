package pgp.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPUtil;
import com.softwareag.pgp.PGPInit;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;
import org.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator;
import org.bouncycastle.openpgp.operator.jcajce.JcePBESecretKeyDecryptorBuilder;
// --- <<IS-END-IMPORTS>> ---

public final class test

{
	// ---( internal utility methods )---

	final static test _instance = new test();

	static test _newInstance() { return new test(); }

	static test _cast(Object o) { return (test)o; }

	// ---( server methods )---




	public static final void readPrivateKeys (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readPrivateKeys)>> ---
		// @specification pgp.specifications:readPrivateKeysSpec
		// @subtype unknown
		// @sigtype java 3.5
		// Get input
		IDataCursor pc = pipeline.getCursor();
		String path = IDataUtil.getString(pc, "path");
		String pasw = IDataUtil.getString(pc, "password");
		
		// Read private keys from file
		IData data = IDataFactory.create();
		PGPSecretKeyRingCollection ringSecret = null;
		try {
		    IDataCursor dc = data.getCursor();
		    //path = Test.test();
		    //path = PGPKeyReader.test();
		    ringSecret = readSecretKeyRing(path);
		    IDataUtil.put(dc, "noOfPrivateKeyRing", ringSecret.size());
		    IDataUtil.put(dc, "privateKeyRing", ringSecret);
		    if (pasw != null) {
		        main: for (Iterator<?> i = ringSecret.getKeyRings(); i.hasNext();) {
		            PGPSecretKeyRing ring = (PGPSecretKeyRing) i.next();
		            for (Iterator<?> j = ring.getSecretKeys(); j.hasNext();) {
		                PGPSecretKey next = (PGPSecretKey) j.next();
		                try {
		                	PGPPrivateKey key = next.extractPrivateKey(
		         	               new JcePBESecretKeyDecryptorBuilder().setProvider( new BouncyCastleProvider() ).build( pasw.toCharArray() ) );
		                    if (key != null) {
		                        IDataUtil.put(dc, "privateKey", key);
		                        IDataUtil.put(dc, "keyId", String.valueOf(key.getKeyID()));
		                       // IDataUtil.put(dc, "algorithm", key.getKey().getAlgorithm());
		                       // IDataUtil.put(dc, "format", key.getKey().getFormat());
		                        IDataUtil.put(dc, "isSigningKey", String.valueOf(next.isSigningKey()));
		                        IDataUtil.put(dc, "isMasterKey", String.valueOf(next.isMasterKey()));
		                        break main;
		                    }
		                } catch (Exception e) {
		                	IDataUtil.put(dc, "errorInside", e.getLocalizedMessage());
		                }
		            }
		        }
		    }
		    dc.destroy();
		} catch (Exception e) {
		    //throw new RuntimeException("Unable to read private key file: "
		           // + e.getMessage());
		    IDataUtil.put( pc , "errorOutsideside", e.getLocalizedMessage());
		}
		
		// Return data
		IDataUtil.put(pc, "privateKeyData", data);
		pc.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void readPublicKeys (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readPublicKeys)>> ---
		// @specification pgp.specifications:readPublicKeysSpec
		// @subtype unknown
		// @sigtype java 3.5
		// Get input
		IDataCursor pc = pipeline.getCursor();
		String path = IDataUtil.getString(pc, "path");
		String alg = IDataUtil.getString(pc, "keyExchangeAlgorithm");
		
		
		// Read public keys from file 
		IData data = IDataFactory.create();
		PGPPublicKeyRingCollection ringPub = null;
		PGPPublicKey keyPub = null;
		try {
		    IDataCursor dc = data.getCursor();
		    ringPub = readPublicKeyRing(path);		    
		    IDataUtil.put(dc, "publicKeyRing", ringPub);
		    IDataUtil.put(dc, "publicKeySize", ringPub.size());
		    if (alg != null) {
		       // keyPub = PGPKeyReader.readPublicKey(ringPub, PGPInit.getKeyExchangeAlgorithm(alg));
		        keyPub = readPublicKey(ringPub, PGPInit.getKeyExchangeAlgorithm(alg));
		        IDataUtil.put(dc, "publicKey", keyPub);
		        IDataUtil.put(dc, "keyId", String.valueOf(keyPub.getKeyID()));
		        IDataUtil.put(dc, "algorithm", String.valueOf(keyPub.getAlgorithm()));
		        IDataUtil.put(dc, "bitStrength", String.valueOf(keyPub.getBitStrength()));
		        IDataUtil.put(dc, "isEncryptionKey", String.valueOf(keyPub.isEncryptionKey()));
		        IDataUtil.put(dc, "isMasterKey", String.valueOf(keyPub.isMasterKey()));
		        IDataUtil.put(dc, "isRevoked", String.valueOf(keyPub.isRevoked()));
		    } 
		    dc.destroy();
		} catch (Exception e) {
		    //throw new ServiceException("Unable to read key file: "
		           // + e.getMessage());
		    IDataUtil.put(pc, "errorMessage", e.getLocalizedMessage());
		}
		
		// Return data
		IDataUtil.put(pc, "publicKeyData", data);
		pc.destroy();
			
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static PGPPublicKeyRingCollection readPublicKeyRing(String path) 
	        throws IOException, PGPException {
	    
	        PGPPublicKeyRingCollection coll = null;
	        
	        
	        try (        		
	            // Access file as stream
	    		InputStream in = new FileInputStream(new File(path));
	            // Get the decoder stream (auto-disarming)
	    		InputStream din = PGPUtil.getDecoderStream(in);
	    		)
	        {
	                    
	            // Open the key ring
	            coll = new PGPPublicKeyRingCollection(din, new JcaKeyFingerprintCalculator());
	        } catch (IOException ioe) {
	            //logger.error(ioe.getMessage());
	            throw ioe;
	        } catch (PGPException pgpe) {
	            //logger.error(pgpe.getMessage());
	            throw pgpe;
	        }
	        return coll;
	    }
	
	public static PGPPublicKey readPublicKey(PGPPublicKeyRingCollection coll, int algorithm) 
	        throws IOException, PGPException {
	
	        ArrayList<String> others = new ArrayList<String>();
	        PGPPublicKey key = null;
	        main: for (Iterator<?> i = coll.getKeyRings(); i.hasNext();) {
	            PGPPublicKeyRing ring = (PGPPublicKeyRing) i.next();
	            for (Iterator<?> j = ring.getPublicKeys(); j.hasNext();) {
	                PGPPublicKey next = (PGPPublicKey) j.next();
	                //logger.debug("Found public key: " 
	                //        + PGPInit.getKeyExchangeAlgorithm(next.getAlgorithm()));
	                if (next.isEncryptionKey()
	                        && (next.getAlgorithm() == algorithm || algorithm == 0)) {
	                    key = next;
	                    break main;
	                } else {
	                    others.add(PGPInit.getKeyExchangeAlgorithm(next.getAlgorithm()));
	                }
	            }
	        }
	        
	        // If not found, throw error
	        if (key == null) {
	            if (others.size() > 0) {
	                StringBuffer buffer = new StringBuffer();
	                String sep = "";
	                for (int i = 0; i < others.size(); i++) {
	                    buffer.append(sep).append(others.get(i));
	                    sep = ", ";
	                }
	                throw new PGPException("Public key not found; Choose algorithm from " + buffer.toString());
	            } else {
	                throw new PGPException("Public key not found");
	            }
	        }
	        return key;
	    }
	
	public static PGPSecretKeyRingCollection readSecretKeyRing(String path) 
	        throws IOException, PGPException {
	
	        PGPSecretKeyRingCollection coll = null;
	        
	        try (
	            // Access file as stream
	    		InputStream in = new FileInputStream(new File(path));
	            // Get the decoder stream (auto-disarming)
	    		InputStream din = PGPUtil.getDecoderStream(in);
	        	
	        ){
	        
	
	            // Open the key ring
	            coll = new PGPSecretKeyRingCollection(din, new JcaKeyFingerprintCalculator());
	        } catch (IOException ioe) {
	            //logger.error(ioe.getMessage());
	            throw ioe;
	        } catch (PGPException pgpe) {
	            //logger.error(pgpe.getMessage());
	            throw pgpe;
	        }
	        return coll;
	    }
	// --- <<IS-END-SHARED>> ---
}

